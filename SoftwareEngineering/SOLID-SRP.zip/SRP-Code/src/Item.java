

public class Item {
	long price ;

	public Item(long price) {
		super();
		this.price = price;
	}

	public long getPrice() {
		return price;
	}

}
