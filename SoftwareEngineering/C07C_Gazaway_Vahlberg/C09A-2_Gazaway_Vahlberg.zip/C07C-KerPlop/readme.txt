Author: Ty Gazaway and Nathan Vahlberg
Section: C