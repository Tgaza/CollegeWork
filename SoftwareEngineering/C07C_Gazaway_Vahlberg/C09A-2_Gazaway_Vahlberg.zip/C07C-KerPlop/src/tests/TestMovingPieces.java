/*	The TestMovingPieces class tests all of the moveable game pieces ability to move according to their
 * design.
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/22/2024
 * 
 * 
 * 
 * */

package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import gameEngine.Drawable;
import gameEngine.GameEngine;
import gameEngine.InteractionResult;
import levelPieces.BigRock;
import levelPieces.Dynamite;
import levelPieces.RoadRunner;
import levelPieces.Sentry;
import levelPieces.SmallRock;
import levelPieces.SpikyRock;
import levelPieces.TumbleWeed;

class TestMovingPieces {
	private Drawable [] gameBoard;
	
	//Setup
	@BeforeEach
	public void testSetUp() {
		gameBoard = new Drawable[GameEngine.BOARD_SIZE];
	}
	
	//TumbleWeed
	@Test
	public void testTumbleWeed() {
		//o|@| |o| |o|o|o| | | |o|o|o|o|o|o|o|o|o| 
		//Place smallRock obstacles for tumbleweed to jump over
		gameBoard[0] = new SmallRock();

		gameBoard[3] = new SmallRock();
		
		for (int i=5; i<=7; i++)
			gameBoard[i] = new SmallRock();
		
		for (int i=11; i<20; i++)
			gameBoard[i] = new SmallRock();
		
		//Place tumbleweed at position 1
		TumbleWeed tumble = new TumbleWeed(1);
		gameBoard[1] = tumble;
		int[] validLocations = {1,2,4,8,9,10,20};
		for (int i=0; i< 7; i++) {
			assertTrue(validLocations[i] == tumble.getLocation());
			tumble.move(gameBoard, 9);
		}
		assertTrue(1 == tumble.getLocation());
	}
	
	//RoadRunner
	@Test
	public void testRoadRunner() {
		//o|R| |o| |o|o|o| | | | | | | |P| | | | |  
		//Place smallRock obstacles for tumbleweed to jump over
		int playerLoc = 15;
		gameBoard[0] = new SmallRock();

		gameBoard[3] = new SmallRock();

		for (int i=5; i<=7; i++)
			gameBoard[i] = new SmallRock();

		//Place RoadRunner at position 1
		RoadRunner R = new RoadRunner(1);
		gameBoard[1] = R;
		int[] validLocations = {1,2,4,8,9,10,11};
		for (int i=0; i< 7; i++) {
			System.out.println(validLocations[i]+ " | " + R.getLocation());
			assertTrue(validLocations[i] == R.getLocation());
			R.move(gameBoard, playerLoc);
		}
		assertTrue(12 == R.getLocation());
		
		playerLoc -= 2;
		R.move(gameBoard, playerLoc);
		assertTrue(10 == R.getLocation());
		
		int[] validLocations2 = {10,9,8,4};
		for (int i=0; i< 4; i++) {
			System.out.println(i + " | " + validLocations2[i]+ " | " + R.getLocation());
			assertTrue(validLocations2[i] == R.getLocation());
			R.move(gameBoard, playerLoc--);
			System.out.println(i + " | " + playerLoc);
		}
		assertTrue(13 == R.getLocation());
		
		int[] validLocations3 = {13,14,16,18,20};
		for (int i=0; i< 5; i++) {
			System.out.println(i + " | " + validLocations3[i]+ " | " + R.getLocation());
			assertTrue(validLocations3[i] == R.getLocation());
			playerLoc += 2;
			R.move(gameBoard, playerLoc);
			System.out.println(i + " | " + playerLoc);
		}
		assertTrue(1 == R.getLocation());
	}

}
