/*	The TestInteractions class test the ability of all the interactable game pieces to correctly interact
 * with the Player.
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/22/2024
 * 
 * 
 * 
 * */
package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import gameEngine.Drawable;
import gameEngine.GameEngine;
import gameEngine.InteractionResult;
import levelPieces.BigRock;
import levelPieces.Dynamite;
import levelPieces.RoadRunner;
import levelPieces.Sentry;
import levelPieces.SmallRock;
import levelPieces.SpikyRock;
import levelPieces.TumbleWeed;

class TestInteractions {
	private Drawable [] gameBoard;
	
	//Setup
	@BeforeEach
	public void testSetUp() {
		gameBoard = new Drawable[GameEngine.BOARD_SIZE];
	}
	
	//BigRock Testing
	@Test
	public void testBigRock() {
		BigRock O = new BigRock(10);
		gameBoard[10] = O;
		// Hit points if player on same space
		assertEquals(InteractionResult.HIT, O.interact(gameBoard, 10));
		// These loops ensure no interaction if not on same space
		for (int i=0; i<10; i++) {
			assertEquals(InteractionResult.NONE, O.interact(gameBoard, i));
		}
		
		for (int i=11; i<GameEngine.BOARD_SIZE; i++) {	
			assertEquals(InteractionResult.NONE, O.interact(gameBoard, i));
		}
	}
	
	//SpikyRock
	@Test
	public void testSpikyRock() {
		SpikyRock X = new SpikyRock(10);
		gameBoard[10] = X;
		// Hit points if player is directly next to but not on top
		assertEquals(InteractionResult.HIT, X.interact(gameBoard, 9));
		assertEquals(InteractionResult.HIT, X.interact(gameBoard, 11));
		// These loops ensure no interaction if not directly next to the spiky rock
		// The line in between loops ensures no interaction when on same space
		for (int i=0; i<9; i++) {
			assertEquals(InteractionResult.NONE, X.interact(gameBoard, i));
		}

		assertEquals(InteractionResult.NONE, X.interact(gameBoard, 10));
		
		for (int i=12; i<GameEngine.BOARD_SIZE; i++) {	
			assertEquals(InteractionResult.NONE, X.interact(gameBoard, i));
		}
	}
	
	//Dynamite
	@Test
	public void testDynamite() {
		Dynamite i = new Dynamite(10);
		gameBoard[10] = i;
		// Gives a Point if player on same space
		assertEquals(InteractionResult.GET_POINT, i.interact(gameBoard, 10));
		// These loops ensure no interaction if not on same space
		for (int j=0; j<10; j++) {
			assertEquals(InteractionResult.NONE, i.interact(gameBoard, j));
		}
		
		for (int j=11; j<GameEngine.BOARD_SIZE; j++) {	
			assertEquals(InteractionResult.NONE, i.interact(gameBoard, j));
		}
	}
	
	//TumbleWeed
	@Test
	public void testTumbleWeed() {
		TumbleWeed tumble = new TumbleWeed(10);
		gameBoard[10] = tumble;
		// Kills if player is directly to the right of the tumbleweed.
		assertEquals(InteractionResult.KILL, tumble.interact(gameBoard, 11));
		// These loops ensure no interaction if not directly in front of the tumbleweed
		for (int i=0; i<11; i++) {
			assertEquals(InteractionResult.NONE, tumble.interact(gameBoard, i));
		}
		
		for (int i=12; i<GameEngine.BOARD_SIZE; i++) {	
			assertEquals(InteractionResult.NONE, tumble.interact(gameBoard, i));
		}
	}
	
	//RoadRunner
	@Test
	public void testRoadRunner() {
		RoadRunner R = new RoadRunner(10);
		gameBoard[10] = R;
		// Advances player if player on same space
		assertEquals(InteractionResult.ADVANCE, R.interact(gameBoard, 10));
		// These loops ensure no interaction if not on same space
		for (int i=0; i<10; i++) {
			assertEquals(InteractionResult.NONE, R.interact(gameBoard, i));
		}
		
		for (int i=11; i<GameEngine.BOARD_SIZE; i++) {	
			assertEquals(InteractionResult.NONE, R.interact(gameBoard, i));
		}
	}
	
	//Sentry
	@Test
	public void testSentry() {
		Sentry T = new Sentry(10);
		SmallRock shield = new SmallRock();
		gameBoard[10] = T;
		gameBoard[7] = shield;
		// Does nothing if player is not within line of sight and has any gamePiece
		// between the player and the sentry
		for (int i=0; i<7; i++) {
			assertEquals(InteractionResult.NONE, T.interact(gameBoard, i));
		}
		
		// Hit points if player is within line of sight and not blocked by any other gamePiece
		for (int i=7; i<GameEngine.BOARD_SIZE; i++) {	
			assertEquals(InteractionResult.HIT, T.interact(gameBoard, i));
		}
	}

}
