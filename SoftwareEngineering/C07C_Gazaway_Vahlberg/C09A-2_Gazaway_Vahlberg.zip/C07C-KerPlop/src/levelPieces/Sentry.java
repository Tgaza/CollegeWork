/*	The Sentry class is a game piece that attacks the player if it has line of sight with no obstruction.
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/18/2024
 * 
 * 
 * 
 * */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;

public class Sentry extends GamePiece{
	
	public Sentry(int startingLoc) {
		super('T', "Sentry", startingLoc);
	}
	
	//Checks if there are any objects between the sentry and the player
	//If so do nothing, if not hit the player
	@Override
	public InteractionResult interact(Drawable[] gameBoard, int playerLocation) {
		int direction = 1;
		if(this.getLocation()-playerLocation > 0) {
			direction = -1;
		}else if(this.getLocation()-playerLocation == 0) {
			return InteractionResult.HIT;
		}
		int i = this.getLocation()+direction;
		while(i != playerLocation && gameBoard[i] == null) {
			i+=direction;
		}
		if(i == playerLocation) {
			return InteractionResult.HIT;
		}
		return InteractionResult.NONE;
	}
}
