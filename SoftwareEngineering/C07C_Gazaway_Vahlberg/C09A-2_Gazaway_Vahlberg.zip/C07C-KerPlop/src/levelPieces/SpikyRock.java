/*	The Spiky Rock class is a game piece that damages the player if they are directly next to it but
 *  not on top of it.
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/18/2024
 * 
 * 
 * 
 * */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;

public class SpikyRock extends GamePiece{
	
	public SpikyRock(int startingLoc) {
		super('X', "Spiky Rock", startingLoc);
	}
	
	@Override
	public InteractionResult interact(Drawable[] gameBoard, int playerLocation) {
		if(this.getLocation()-1 == playerLocation || this.getLocation()+1 == playerLocation) {
			return InteractionResult.HIT;
		}
		return InteractionResult.NONE;
	}
}
