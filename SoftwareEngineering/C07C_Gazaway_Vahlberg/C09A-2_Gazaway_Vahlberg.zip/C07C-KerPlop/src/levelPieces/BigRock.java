/* The Big Rock class is a game piece that damages the player if they are directly on top of it by causing 
 * them to trip and faceplant.
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/18/2024
 * 
 * 
 * 
 * */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;

public class BigRock extends GamePiece{
	
	public BigRock(int startingLoc) {
		super('O', "Big Rock", startingLoc);
	}
	
	@Override
	public InteractionResult interact(Drawable[] gameBoard, int playerLocation) {
		if(this.getLocation() == playerLocation) {
			return InteractionResult.HIT;
		}
		return InteractionResult.NONE;
	}
}
