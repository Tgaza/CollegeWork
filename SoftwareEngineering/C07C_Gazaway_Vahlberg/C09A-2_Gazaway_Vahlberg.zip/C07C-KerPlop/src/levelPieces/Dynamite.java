/*	The Dynamite class is a game piece that gives the player a point if they pick it up.
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/18/2024
 * 
 * 
 * 
 * */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;

public class Dynamite extends GamePiece{
	
	public Dynamite(int startingLoc) {
		super('i', "Dynamite", startingLoc);
	}
	
	@Override
	public InteractionResult interact(Drawable[] gameBoard, int playerLocation) {
		if(this.getLocation() == playerLocation) {
			return InteractionResult.GET_POINT;
		}
		return InteractionResult.NONE;
	}
}