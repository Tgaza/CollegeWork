/* The Small Rock class is a drawable object that does nothing.
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/18/2024
 * 
 * 
 * 
 * */
package levelPieces;

import gameEngine.Drawable;

public class SmallRock implements Drawable{

	@Override
	public void draw() {
		System.out.print("o");
	}
}
