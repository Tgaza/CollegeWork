/*	The TumbleWeed class is a game piece that damages the player if they are directly in front of but
 *  not on top of it. It also moves one space to the right every turn, hops over other pieces, and wraps
 *  around to the beginning of the board when it reaches the end.
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/18/2024
 * 
 * 
 * 
 * */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;
import gameEngine.Moveable;

public class TumbleWeed extends GamePiece implements Moveable{
	
	public TumbleWeed( int location) {
		super('@', "TumbleWeed", location);
	}
	
	@Override
	public InteractionResult interact(Drawable[] gameBoard, int playerLocation) {
		if(this.getLocation()+1 == playerLocation) {
			return InteractionResult.KILL;
		}
		return InteractionResult.NONE;
	}

	@Override
	public void move(Drawable[] gameBoard, int playerLocation) {
		int newLocation = this.getLocation();
			do {
				newLocation++;
				if(newLocation >= gameBoard.length) newLocation = 0;
			}while(gameBoard[newLocation] != null);
		int oldLocation = this.getLocation();
		this.setLocation(newLocation);
		gameBoard[this.getLocation()] = this;
		gameBoard[oldLocation] = null;
	}
}
