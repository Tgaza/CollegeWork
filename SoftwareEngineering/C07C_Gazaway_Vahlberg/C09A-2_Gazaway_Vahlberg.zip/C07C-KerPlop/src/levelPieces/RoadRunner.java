/*	The RoadRunner is a class which is an evil game piece. The RoadRunner will move such that it is just out
 * of reach of the player while taunting them with a guaranteed win if they catch it.
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/18/2024
 * 
 * 
 * 
 * */
package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;
import gameEngine.Moveable;

public class RoadRunner extends GamePiece implements Moveable{

	public RoadRunner(int startingLoc) {
		super('R', "RoadRunner", startingLoc);
	}

	@Override
	public InteractionResult interact(Drawable[] gameBoard, int playerLocation) {
		if(this.getLocation() == playerLocation) {
			return InteractionResult.ADVANCE;
		}
		return InteractionResult.NONE;
	}

	//Assesses where the roadrunner is in relation to the player and passes that information to the look
	//for spot method
	@Override
	public void move(Drawable[] gameBoard, int playerLocation) {
		int distanceFromP = Math.abs(playerLocation-this.getLocation());
		int direction = -1;
		boolean moveAway = true;
		if(playerLocation-this.getLocation() > 0) {
			direction = 1;
		}
		if(distanceFromP > 3) {
			moveAway = false;
		}
		lookForSpot(gameBoard, playerLocation, moveAway, direction, distanceFromP);
	}

	//Looks for an available spot that fits the parameters of the roadrunner gamepiece
	private void lookForSpot(Drawable[] gameBoard, int playerLocation, boolean moveAway, int direction, int distanceFromP) {
		int newLocation;
		if(moveAway) {
			direction *= -1;
		}
		if(distanceFromP == 1) {
			newLocation = direction*2+this.getLocation();
		}else {
			newLocation = direction*1+this.getLocation();
		}
		if((newLocation >= 0 && newLocation < gameBoard.length)) {
			while((newLocation >= 0 && newLocation < gameBoard.length) && gameBoard[newLocation] != null || Math.abs(newLocation-playerLocation) <= 2) {
				newLocation += direction*1;
			}
		}
		if((newLocation < 0 || newLocation >= gameBoard.length)) {
			if(newLocation < 0) {
				newLocation = gameBoard.length-1;
				while(gameBoard[newLocation] != null) {
					newLocation--;
				}
			}else {
				newLocation = 0;
				while(gameBoard[newLocation] != null) {
					newLocation++;
				}
			}
		}
		int oldLocation = this.getLocation();
		this.setLocation(newLocation);
		gameBoard[this.getLocation()] = this;
		gameBoard[oldLocation] = null;
	}
}
