/*
 * 
 * 
 * Authors: Ty Gazaway and Nathan Vahlberg
 * Date: 09/18/2024
 * Sources: StackOverflow(https://stackoverflow.com/questions/766106/test-if-object-implements-interface)
 * 
 * 
 * 
 * */


package levelPieces;

import gameEngine.GameEngine;
import gameEngine.Moveable;
import gameEngine.Drawable;
import java.util.ArrayList;

public class LevelSetup {
	private Drawable[] gameBoard;
	private ArrayList<Moveable> moveablePieces;
	private ArrayList<GamePiece> interactablePieces;
	private int playerStartLoc;
	
	public LevelSetup() {
		gameBoard = new Drawable[GameEngine.BOARD_SIZE];
		moveablePieces = new ArrayList<Moveable>();
		interactablePieces = new ArrayList<GamePiece>();
	}
	
	public void createLevel(int levelNum) {
		gameBoard = new Drawable[GameEngine.BOARD_SIZE];
		moveablePieces.clear();
		interactablePieces.clear();
		switch(levelNum) {
		case(1):
			setupLevelOne();
			break;
		case(2):
			setupLevelTwo();
			break;
		case(3):
			setupLevelThree();
			break;
		}
		addPiecesToLists();
			
	}
	
	public Drawable[] getBoard() {
		return gameBoard;
	}
	
	public ArrayList<Moveable> getMovingPieces(){
		return moveablePieces;
	}
	
	public ArrayList<GamePiece> getInteractingPieces(){
		return interactablePieces;
	}
	
	public int getPlayerStartLoc() {
		return playerStartLoc;
	}
	
	public void setupLevelOne() {
		// i| |X| |i| |@| |O|o| | |P| | |O| | |R| | |
		gameBoard[0] = new Dynamite(0);
		gameBoard[2] = new SpikyRock(2);
		gameBoard[4] = new Dynamite(4);
		gameBoard[6] = new TumbleWeed(6);
		gameBoard[8] = new BigRock(8);
		gameBoard[9] = new SmallRock();
		gameBoard[15] = new BigRock(15);
		gameBoard[18] = new RoadRunner(18);
		
		playerStartLoc = 12;
	}
	
	public void setupLevelTwo() {
		// T| |i| |i|X| | | |P| |X| | |@|R| | |o|i| | 
		gameBoard[0] = new Sentry(0);
		gameBoard[2] = new Dynamite(2);
		gameBoard[4] = new Dynamite(4);
		gameBoard[5] = new SpikyRock(5);
		gameBoard[11] = new SpikyRock(11);
		gameBoard[14] = new TumbleWeed(14);
		gameBoard[15] = new RoadRunner(15);
		gameBoard[18] = new SmallRock();
		gameBoard[19] = new Dynamite(19);
		
		playerStartLoc = 9;
	}
	
	public void setupLevelThree() {
		// |R|i| |X| |P| | |@| | |X|o| | |O| |i| | |T 
		gameBoard[1] = new RoadRunner(1);
		gameBoard[2] = new Dynamite(2);
		gameBoard[4] = new SpikyRock(4);
		gameBoard[9] = new TumbleWeed(9);
		gameBoard[12] = new SpikyRock(12);
		gameBoard[13] = new SmallRock();
		gameBoard[16] = new BigRock(16);
		gameBoard[18] = new Dynamite(18);
		gameBoard[20] = new Sentry(20);
		
		playerStartLoc = 6;
	}
	
	public void addPiecesToLists() {
		for(Drawable piece: gameBoard) {
			if(piece instanceof Moveable) {
				moveablePieces.add((Moveable)piece);
			}
			if(piece instanceof GamePiece) {
				interactablePieces.add((GamePiece)piece);
			}
		}
	}
}
