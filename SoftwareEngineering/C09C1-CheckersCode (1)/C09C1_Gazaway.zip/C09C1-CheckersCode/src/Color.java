/** 
 * Color: Enum used for Tiles and Pieces
 * Author: Caleb Bartel 
 */

public enum Color {
	RED, BLACK
}
