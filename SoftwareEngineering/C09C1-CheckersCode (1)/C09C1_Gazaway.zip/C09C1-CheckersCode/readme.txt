Author: Ty Gazaway
Section: C
