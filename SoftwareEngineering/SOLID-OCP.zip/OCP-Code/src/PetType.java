
public enum PetType {
	CAT, DOG
}
