
public interface Switchable {
	public abstract void turnOn();

	public abstract void turnOff();
}
